function removeItem(typ){
	var locSel = document.getElementById(typ + "_text")
	locSel.value = ""
}

			
function addItem(typ){
	var loc = document.getElementById(typ)
	var locSel = document.getElementById(typ + "_text")
	if (locSel.value == "")
		{
			locSel.value = loc.value;
		}
	else if (locSel.value.search(loc.value) != -1){}
	else if (loc.value != "")
		{
			locSel.value = locSel.value + ";" + loc.value;
		}
	loc.value = "";
}


function create_JD_List(){
	var lov = document.getElementById("JD_List");
	
	for (i=0 ; i < jd_data.length ; i++){
			var _option = lov.appendChild(document.createElement('option'));
			if (i > 0){
			_option.value = jd_data[i].JD_Title;
			}
		}
}


function create_lov(lov_name){
	var lov = document.getElementById(lov_name);
	
	for (i in jd_data[0][lov_name])
		{
			var _option = lov.appendChild(document.createElement('option'));
			_option.value = jd_data[0][lov_name][i];
		}
}


function create_CTC_lov(lov_name){
	lov = document.getElementById(lov_name);
	var option = "";
	var val = 20;
	var multiplier = 5;
	var mctc = 0;
	
	if (lov_name == "CTC_max_lkh_lov" || lov_name == "CTC_min_lkh_lov")
	{
		document.getElementById("CTC_max_lkh").value = null;
		mctc = document.getElementById("CTC_min_lkh").value;
		val = 40
		multiplier = 1;
	}
	
	if (lov_name == "CTC_max_th_lov")
	{
		document.getElementById("CTC_max_th").value = null;
		if (document.getElementById("CTC_min_lkh").value == document.getElementById("CTC_max_lkh").value)
			{
				mctc = document.getElementById("CTC_min_th").value;
				mctc = mctc / 5;
			}
	}
	
	while (mctc<val)
		{
			option += '<option value='+ mctc*multiplier + ' />';
			mctc++;
		}
	lov.innerHTML = option;
}


function init_function(){
	var option = "";
	var lov = document.getElementById("CTC_min_th_lov");
	
	for(i=0; i<20; i++)
		{
			option += '<option value='+ (i*5) + ' />';
		}
	lov.innerHTML = option;
	
	document.getElementById("Current_loc_text").value = "";
	document.getElementById("Pref_loc_text").value = "";
	document.getElementById("Education_ug_text").value = "";
	document.getElementById("Education_pg_text").value = "";
	document.getElementById("Notice_Period_text").value = "";
}


function SubmitJD(){
	var idx = 0
	var jd_Title = document.getElementById("IDX").value;
	for (i=0 ; i < jd_data.length ; i++)
		{
		if (jd_data[i].JD_Title == jd_Title)
			{
				idx=i;
			}
		}
	document.getElementById("Requisition_ID").value = jd_data[idx].Requisition_ID;
	document.getElementById("Key_Skills").value = jd_data[idx].Key_Skills;
	document.getElementById("May_Know_Skills").value = jd_data[idx].May_Know_Skills;
}

function SubmitValues(search_option){
	var JD_Title = document.getElementById("IDX").value;
	var Requisition_ID = document.getElementById("Requisition_ID").value;
	var Key_Skills = document.getElementById("Key_Skills").value;
	var May_Know_Skills = document.getElementById("May_Know_Skills").value;
	if (search_option == "EXIT" ){
		window.external.setResult(search_option + ":" + JD_Title + ":" + Requisition_ID + ":" + Key_Skills + ":" + May_Know_Skills + ":");
		return true;
	}
	else if (Key_Skills == "" ){
		window.alert("Key Skills can not be empty");
	}
	else{
		window.external.setResult(search_option + ":" + JD_Title + ":" + Requisition_ID + ":" + Key_Skills + ":" + May_Know_Skills + ":");
		return true;
	}
}


var jd_data = JSON.parse(data);


create_JD_List();
create_lov("location_lov");
create_lov("education_pg_lov");
create_lov("education_ug_lov");
create_CTC_lov("CTC_min_lkh_lov");
document.getElementById("JDD").style.display = "block";
init_function();
