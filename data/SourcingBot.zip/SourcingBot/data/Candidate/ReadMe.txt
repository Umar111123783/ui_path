Candidate score results are stored in this directory.
